library(shiny)
library(shinydashboard)
library(DT)
library(dplyr)
library(tidyr)
library(leaflet)
library(sp)
library(rworldmap)
library(rnaturalearth)
library(rnaturalearthdata)
library(sf)
library(plotly)
library(readr)
library(rgdal)
library(stringr)

## global values ##

# Read the CSV file
my_data <- read.delim("dataset.tsv")
my_data <- my_data %>% separate(nace_r2.wstatus.worktime.age.sex.unit.geo.time, into = c('nace_r2', 'wstatus', 'worktime', 'age', 'sex', 'unit', 'geo'), sep = ",")

# Split the data by header columns
headers <- my_data[1, ]
data <- my_data[-1, ]

myspdf = readOGR(dsn=getwd(), layer="TM_WORLD_BORDERS_SIMPL-0.3")
head(myspdf)
summary(myspdf)
head(myspdf@data)

invalid_data = c(': ', ': u', ': bu', 'numeric(0)')

regions <- c(
  "Belgium", "Bulgaria", "Czechia", "Denmark", "Germany",
  "Estonia", "Ireland", "Greece", "Spain", "France",
  "Croatia", "Italy", "Cyprus", "Latvia", "Lithuania",
  "Luxembourg", "Hungary", "Malta", "Netherlands", "Austria",
  "Poland", "Portugal", "Romania", "Slovenia", "Slovakia",
  "Finland", "Sweden", "Iceland", "Norway", "Switzerland",
  "United Kingdom", "Montenegro", "North Macedonia", "Serbia", "Turkey", "Europen Union", "Euro area"
)

europe_iso2 <- c("AL", "AD", "AT", "BY", "BE", "BA", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IS", "IE", "IT", "XK", "LV", "LI", "LT", "LU", "MK", "MT", "MD", "MC", "ME", "NL", "NO", "PL", "PT", "RO", "RU", "SM", "RS", "SK", "SI", "ES", "SE", "CH", "UA", "GB", "VA")

age_ranges_ext <- c("From 15 to 24 years", "From 15 to 34 years", "From 15 to 64 years", "15 years or over", "From 20 to 64 years", "From 25 to 54 years", "From 25 to 64 years", "From 35 to 49 years", "50 years or over", "From 55 to 64 years")
age_ranges <- c("Y15-24", "Y15-34", "Y15-64", "Y_GE15", "Y20-64", "Y25-64", "Y25-64", "Y35-49", "Y_GE50", "Y55-64")
sexes_ext <- c("Males", "Females", "Total")
sexes <- c("M", "F", "T")
activity_ext <- c("Employed persons", "Employees", "Employed persons except employees", "Self-employed persons", "Self-employed persons with employees (employers)", "Self-employed persons without employees (own-account workers)", "Contributing family workers", "Employed persons except contributing family workers", "No response")
activity <- c("EMP", "SAL", "NSAL", "SELF", "SELF_S", "SELF_NS", "CFAM", "NCFAM", "NRP")
years <- c(2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022)
years_ext <- paste0("X", as.character(years))
working_time_ext <- c("Total", "Part-time", "Full-time", "No response")
working_time <- c("TOTAL", "PT", "FT", "NRP")
classification_ext <- c(
  "Total - all NACE activities",
  "Agriculture, forestry and fishing",
  "Mining and quarrying",
  "Manufacturing",
  "Electricity, gas, steam and air conditioning supply",
  "Water supply; sewerage, waste management and remediation activities",
  "Construction",
  "Wholesale and retail trade; repair of motor vehicles and motorcycles",
  "Transportation and storage",
  "Accommodation and food service activities",
  "Information and communication",
  "Financial and insurance activities",
  "Real estate activities",
  "Professional, scientific and technical activities",
  "Administrative and support service activities",
  "Public administration and defence; compulsory social security",
  "Education",
  "Human health and social work activities",
  "Arts, entertainment and recreation",
  "Other service activities",
  "Activities of households as employers; undifferentiated goods- and services-producing activities of households for own use",
  "Activities of extraterritorial organisations and bodies",
  "No response")

classification <- c("TOTAL", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "NRP")

# Define the UI
ui <- dashboardPage(
  dashboardHeader(title = "Choose tab"),
  dashboardSidebar(
    sidebarMenu(id = "sidebar",
      menuItem("Visualization", tabName = "visualization_tab", icon = icon("chart-line")),
      menuItem("Dataset", tabName = "table_tab", icon = icon("table")),
      menuItem("Map", tabName = "map_tab", icon = icon("map-marker-alt")),
      
      # conditional widgets
      conditionalPanel("input.sidebar == 'visualization_tab'", selectInput(inputId = "age", "Age", "Age", choices = age_ranges_ext)),
      conditionalPanel("input.sidebar == 'visualization_tab'", selectInput(inputId = "sex", "Sex", "Sex", choices = sexes_ext)),
      conditionalPanel("input.sidebar == 'visualization_tab'", selectInput(inputId = "activity", "Activity and employment status", "Activity and employment status", choices = activity_ext)),
      conditionalPanel("input.sidebar == 'visualization_tab'", selectInput(inputId = "year", "Year", "Year", choices = years)),
      conditionalPanel("input.sidebar == 'visualization_tab'", selectInput(inputId = "working_time", "Working time", "Working time", choices = working_time_ext)),
      conditionalPanel("input.sidebar == 'visualization_tab'", selectInput(inputId = "classification", "Classification of economic activities", "Classification of economic activities", choices = classification_ext))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "visualization_tab",
              fluidPage(
                fluidRow(
                  tabPanel("Barplot", value="barplot",
                           plotlyOutput("bar_plot_by_countries", height = "350px"))
                ),
                br(),
                fluidRow(
                  column(width = 2,
                         style = "border: 4px solid CornflowerBlue ; height: 260px; text-align: center; border-radius: 20px;",
                         tags$h4("Top 5 countries in Europe", style = "font-size: 19px;"),
                         tabPanel("Top5", value="top5",
                            tableOutput("high5"))),
                  column(width = 1),
                  column(width = 2,
                         style = "border: 4px solid CornflowerBlue ; height: 260px; text-align: center; border-radius: 20px;",
                         tags$h4("Low 5 countries in Europe", style = "font-size: 19px;"),
                         tabPanel("Bottom5", value="bottom5",
                           tableOutput("low5")))
                )
              )
      ),
      tabItem(tabName = "table_tab",
              fluidPage( title = "Top 5 countries",
                DT::dataTableOutput("data_table")
              )
      ),
      tabItem(tabName = "map_tab",
              fluidPage(
                fluidRow(
                  column(width = 5,
                         style = "border: 4px solid green; height: 120px; text-align: center; border-radius: 20px;",
                         tags$h4("Overall average number of working hours per week in 2022.", style = "font-size: 19px;"),
                         tags$style("#text1 {font-size:22px;
                           color:black;}"),
                         textOutput("text1"),
                  ),
                  column(width = 2,),
                  column(width = 5,
                         style = "border: 4px solid green; height: 120px; text-align: center; border-radius: 20px;",
                         tags$h4("Average number of working hours per week in the Information and Communication sector in 2022.", style = "font-size: 18px;"),
                         tags$style("#text2 {font-size:22px;
                           color:black;}"),
                         textOutput("text2"),
                  ),
                ),
                br(),
                fluidRow(column(width = 5,
                                style = "border: 4px solid green; height: 120px; text-align: center; border-radius: 20px;",
                                tags$h4("Average number of working hours per week among females in the age group 15-24 in 2022.", style = "font-size: 18px;"),
                                tags$style("#text3 {font-size:22px;
                           color:black;}"),
                                textOutput("text3"),
                ),
                column(width = 2,),
                column(width = 5,
                       style = "border: 4px solid green; height: 120px; text-align: center; border-radius: 20px;",
                       tags$h4("Average number of working hours per week among males in the age group 15-24 in 2022.", style = "font-size: 18px;"),
                       tags$style("#text4 {font-size:22px;
                           color:black;}"),
                       textOutput("text4"),
                )
                
                ),
                fluidRow(style = "margin-top: 30px;",
                         leafletOutput(outputId = 'map')
                )
              )
      )
    )
  )
)

# Define the server logic
server <- function(input, output, session) {
  
  rv <- reactiveValues()
  rv$iso <- NULL
  
  output$map <- renderLeaflet({
    leaflet(data=myspdf) %>%
      addTiles() %>%
      setView(lat=47, lng=20 , zoom=4) %>%
      addPolygons(fillColor = ifelse(myspdf$ISO2 %in% europe_iso2, "darkgreen", "black"),
                  layerId = ~ISO2,
                  highlight = highlightOptions(weight = 5,
                                               color = "red",
                                               fillOpacity = 0.7,
                                               bringToFront = TRUE),
                  label=~NAME)
  })
  
  observe({ 
    rv$ISO2 <- input$map_shape_click$id
  })
  
  x1 <- reactive({
    req(rv$ISO2)
    my_data %>%
      filter(geo == rv$ISO2) %>%
      select(X2022)%>%
      subset(X2022!=": " & X2022!=": bu" & X2022!=": u" & str_sub(X2022, -1)!= 'u') %>%
      mutate(X2022 = as.numeric(X2022)) %>%
      mutate(X2022 = mean(X2022)) %>%
      distinct(X2022) %>%
      round(digits = 1)
  })
  
  x2 <- reactive({
    req(rv$ISO2)
    my_data %>%
      filter(nace_r2 == "J") %>%
      filter(geo == rv$ISO2) %>%
      select(X2022)%>%
      subset(X2022!=": " & X2022!=": bu" & X2022!=": u" & str_sub(X2022, -1)!= 'u') %>%
      mutate(X2022 = as.numeric(X2022)) %>%
      mutate(X2022 = mean(X2022)) %>%
      distinct(X2022) %>%
      round(digits = 1)
  })
  
  x3 <- reactive({
    req(rv$ISO2)
    my_data %>%
      filter(age == "Y15-24") %>%
      filter(sex == "F") %>%
      filter(geo == rv$ISO2) %>%
      select(X2022)%>%
      subset(X2022!=": " & X2022!=": bu" & X2022!=": u" & str_sub(X2022, -1)!= 'u') %>%
      mutate(X2022 = as.numeric(X2022)) %>%
      mutate(X2022 = mean(X2022)) %>%
      distinct(X2022) %>%
      round(digits = 1)
  })
  
  x4 <- reactive({
    req(rv$ISO2)
    my_data %>%
      filter(age == "Y15-24") %>%
      filter(sex == "M") %>%
      filter(geo == rv$ISO2) %>%
      select(X2022)%>%
      subset(X2022!=": " & X2022!=": bu" & X2022!=": u" & str_sub(X2022, -1)!= 'u') %>%
      mutate(X2022 = as.numeric(X2022)) %>%
      mutate(X2022 = mean(X2022)) %>%
      distinct(X2022) %>%
      round(digits = 1)
  })
  
  output$text1 <- renderText({
    x1_r <- x1()
    if (! x1_r %in% invalid_data) {
      paste(x1_r)
    } else {
      "N/A"
    }
  })
  
  output$text2 <- renderText({
    x2_r <- x2()
    if (! x2_r %in% invalid_data) {
      paste(x2_r)
    } else {
      "N/A"
    }
  })
  
  output$text3 <- renderText({
    x3_r <- x3()
    if (! x3_r %in% invalid_data) {
      paste(x3_r)
    } else {
      "N/A"
    }
  })
  
  output$text4 <- renderText({
    x4_r <- x4()
    if (! x4_r %in% invalid_data) {
      paste(x4_r)
    } else {
      "N/A"
    }
  })
  
  yearVAL <- reactive({
    years_ext[which(years == input$year)]
  })
  
  
  activityVAL <- reactive({
    activity[which(activity_ext == input$activity)]
  })
  
  working_timeVAL <- reactive({
    working_time[which(working_time_ext == input$working_time)]
  })
  
  sexesVAL <- reactive({
    sexes[which(sexes_ext == input$sex)]
  })
  
  age_rangesVAL <- reactive({
    age_ranges[which(age_ranges_ext == input$age)]
  })
  
  classificationVAL <- reactive({
    classification[which(classification_ext == input$classification)]
  })
  
  
  # Render the table
  output$data_table <- DT::renderDataTable({
    DT::datatable(
      data,
      options = list(
        dom = 'tip',
        autoWidth = TRUE,
        scrollX = TRUE,
        columnDefs = list(list(className = 'dt-center', targets = "_all")),
        lengthMenu = list(c(25, 50, -1), c('25', '50', 'All'))  # Customize the entries per page
      )
    )
  })

  # Rendering plot
  output$bar_plot_by_countries <- renderPlotly({
    my_data %>% 
      filter(substr(yearVAL(), 1, 1) != ":") %>%
      filter(sex == sexesVAL()) %>%
      filter(age == age_rangesVAL()) %>%
      filter(wstatus == activityVAL()) %>%
      filter(worktime == working_timeVAL()) %>%
      filter(nace_r2 == classificationVAL()) %>%
      mutate(x = sapply(strsplit(as.character(get(yearVAL())), " "), "[", 1)) %>%
      group_by(geo) %>%
      summarize(Avg = mean(as.numeric(x), na.rm = TRUE), .groups = 'drop') %>%
      plot_ly() %>%
      add_bars(x=~geo, y=~Avg) %>%
      layout(title = paste("Average number of usual weekly hours of work in main job: "),
             xaxis = list(title = "Region"),
             yaxis = list(title = "Number of hours"))
  })
  
  # Rendering table with 5 countries with lowest hours per week
  output$low5 <- renderTable({
    
    my_data %>% 
      filter(substr(yearVAL(), 1, 1) != ":") %>%
      filter(sex == sexesVAL()) %>%
      filter(age == age_rangesVAL()) %>%
      filter(wstatus == activityVAL()) %>%
      filter(worktime == working_timeVAL()) %>%
      filter(nace_r2 == classificationVAL()) %>%
      mutate(x = sapply(strsplit(as.character(get(yearVAL())), " "), "[", 1)) %>%
      group_by(geo) %>%
      summarize(Avg = mean(as.numeric(x), na.rm = TRUE), .groups = 'drop') %>%
      select(geo, Avg) %>% 
      arrange(desc(Avg)) %>% 
      head(5)
    
  })
  
  # Rendering table with 5 countries with highest hours per week
  output$high5 <- renderTable({
    
    my_data %>% 
      filter(substr(yearVAL(), 1, 1) != ":") %>%
      filter(sex == sexesVAL()) %>%
      filter(age == age_rangesVAL()) %>%
      filter(wstatus == activityVAL()) %>%
      filter(worktime == working_timeVAL()) %>%
      filter(nace_r2 == classificationVAL()) %>%
      mutate(x = sapply(strsplit(as.character(get(yearVAL())), " "), "[", 1)) %>%
      group_by(geo) %>%
      summarize(Avg = mean(as.numeric(x), na.rm = TRUE), .groups = 'drop') %>%
      select(geo, Avg) %>%
      arrange(Avg) %>% 
      head(5)
    
    
  })
  
  
  # Activate the table tab on app start
  observe({
    if (is.null(input$tabName)) {
      updateTabItems(session, "sidebarMenu", "visualization_tab")
    }

  })
}

# Run the application
shinyApp(ui = ui, server = server)